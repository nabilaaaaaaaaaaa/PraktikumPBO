package com.nabilaanandamasyaazahra.UTS_NO3_SI05B_3108;
public class Mahasiswa_3108 {
     protected String nim;
    protected String nama;
    protected String jurusan;
    protected int ipk;
    
    public void tampilDataMhs(){
        
    }
}
