package com.nabilaanandamasyaazahra.UTS_NO3_SI05B_3108;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main_3108{

    public static void main(String[] args) {

         ArrayList<String> list=new ArrayList<String>();
        
    }

}
