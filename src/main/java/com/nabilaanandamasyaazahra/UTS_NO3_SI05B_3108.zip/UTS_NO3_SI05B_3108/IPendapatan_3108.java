package com.nabilaanandamasyaazahra.UTS_NO3_SI05B_3108;
public interface IPendapatan_3108 {
    public double totalPendapatan();
}
