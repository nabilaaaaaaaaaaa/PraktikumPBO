package com.nabilaanandamasyaazahra.UTS_NO2_SI05B_3108;
public class Employees_3108 {
    String nama;
    String nip;

    public Employees_3108(String nama, String nip) {
        this.nama = nama;
        this.nip = nip;
    }
    
    public void tampilData(){
        
    }
    
    public void hitungGaji(){
        
    }
}
